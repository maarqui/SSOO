package ssoo;

public class Cluster {
	int clusterNumber;
	GenericFile gf;
	
	public void fillCluster() {
		
	}
}
