package ssoo;

public class ClusterRef {
	int nClusters;
	Cluster clsuters[];
	boolean dis;
	boolean da;
	boolean res;
	int next;
	boolean fin;
	
	public void changeBool() {
		
	}
}
