package ssoo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Data {
    Map<Integer, String> clusterMap = new HashMap<>();
    List<Cluster> clusterList = new ArrayList<Cluster>();
    List<Directory> directoryList = new ArrayList<Directory>();
    List<File> fileList = new ArrayList<File>();
    int nDirs;
    int nFiles;
    
    public void moveFile() {
    	
    }
    
    public void moveDir() {
    	
    }
   
}