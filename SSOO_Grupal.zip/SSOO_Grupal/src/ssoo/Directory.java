package ssoo;

import java.util.ArrayList;
import java.util.List;

public class Directory {
    String nombre;
    int clusterNumber;
    List<GenericFile> content = new ArrayList<GenericFile>();
    
}