package ssoo;

public class FAT {
	Metadata metaData;
	Data data;

	public void runStartingCode() {

	}

	public void createDir() {

	}

	public void createFile() {

	}

	public void deleteFile() {

	}

	public void deleteDirectory() {

	}

	public void showMetadata() {

	}

	public void listProces() {

	}

	public void launchProces() {

	}

	public void killProces() {

	}
}