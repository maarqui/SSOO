package ssoo;

public class FATCode {

}
