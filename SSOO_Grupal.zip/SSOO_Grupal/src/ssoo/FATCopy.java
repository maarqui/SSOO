package ssoo;

public class FATCopy {

}
