package ssoo;

public class File {
    String name;
    int clusterNumber;

}