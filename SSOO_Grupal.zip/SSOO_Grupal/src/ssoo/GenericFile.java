package ssoo;

public class GenericFile {
	int clusterNumber;
	Directory dir;
	File file;
	
	public void fillCluster() {
		
	}
}
