package ssoo;

public class Metadata {
    ClusterRef refClsuters[];
    RootDir rootDir;
    FATCopy fatCopy;
    FATCode fatCode;
    StartingCode startingCode;
}