package ssoo;

public class RootDir {
    int clusterInic;
    String type;
    String nombre;
    
    public void addReference() {
    	
    }
    
    public void deleteReference() {
    	
    }
}