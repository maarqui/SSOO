package ssoo;

public class StartingCode {

}
