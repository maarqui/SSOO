package ssoo;

public class RootDir {
    int clusterInic;
    String type;
    String name;
    
}